// rizky_cahyono

/*
Goal Tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer
*/
